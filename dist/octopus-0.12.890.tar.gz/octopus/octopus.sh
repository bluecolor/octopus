java -jar octopus.jar -cp "lib/*.jar"
